<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboards extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->output->enable_profiler();
		$this->load->model('Dashboard');
		$this->load->library("form_validation");
	}

	public function index()
	{
		$this->load->view('index');
	}
	public function sign_in()
	{
		$this->load->view('sign_in');
	}
	public function register()
	{
		$this->load->view('register');
	}
	public function display_users()
	{
		$all['all_users'] = $this->Dashboard->all();
		$this->load->view('display_users', $all);
	}
	public function manage_users()
	{
		$all['all_users'] = $this->Dashboard->all();
		$this->load->view('manage_users', $all);
	}
	public function edit_users($id)
	{
		$user['user'] = $this->Dashboard->get_user_by_id($id);
		$this->load->view('edit_user', $user);
	}
	public function board($id)
	{
		$user_data['user'] = $this->Dashboard->get_user_by_id($id);
		$this->load->view('message_board', $user_data);
	}
	public function profile()
	{
		$id = $this->session->userdata('id');
		$user['user'] = $this->Dashboard->get_user_by_id($id);
		$this->load->view('edit_profile', $user);
	}
	public function admin_update_user_info($id)
	{
		$user_info['email'] = $this->input->post('email');
		$user_info['first_name'] = $this->input->post('first_name');
		$user_info['last_name'] = $this->input->post('last_name');
		if($this->input->post('level') == "admin")
		{
			$user_info['level'] = 9;
		}
		else
		{
			$user_info['level'] = 2;
		}

		$user_info['id'] = $id;
		$this->Dashboard->admin_update_user_info($user_info);
		redirect('/dashboards/manage_users');
	}
	public function delete_user($id)
	{
		$this->Dashboard->delete_user_by_id($id);
		redirect('/dashboards/manage_users');
	}
	public function update_user_info()
	{
		$user_info['email'] = $this->input->post('email');
		$user_info['first_name'] = $this->input->post('first_name');
		$user_info['last_name'] = $this->input->post('last_name');
		$user_info['id'] = $this->session->userdata('id');
		$this->Dashboard->update_user_info($user_info);
		redirect('/dashboards/profile');
	}
	public function admin_update_password($id)
	{
		$user_info['password'] = $this->input->post('password');
		$user_info['confirm'] = $this->input->post('confirm');
		$user_info['id'] = $id;
		if ($user_info['password'] == $user_info['confirm'])
		{
		$this->Dashboard->update_password($user_info);
		redirect('/dashboards/managae_users');
		}
		else
		{
		$error = "Password and Confirm password must match!";
		$this->session->set_userdata('error', $error);
		redirect('/dashboards/manage_users');
		}	
	}
	public function update_password()
	{
		$user_info['password'] = $this->input->post('password');
		$user_info['confirm'] = $this->input->post('confirm');
		$user_info['id'] = $this->session->userdata('id');
		if ($user_info['password'] == $user_info['confirm'])
		{
		$this->Dashboard->update_password($user_info);
		redirect('/dashboards/profile');
		}
		else
		{
		$error = "Password and Confirm password must match!";
		$this->session->set_userdata('error', $error);
		redirect('/dashboards/profile');
		}	
	}
	public function update_description()
	{
		$user_info['description'] = $this->input->post('description');
		$user_info['id'] = $this->session->userdata('id');
		$this->Dashboard->update_description($user_info);
		redirect('/dashboards/profile');
	}
	public function login()
	{
		$data['email'] = $this->input->post('email');
		$data['password'] = $this->input->post('password');
		$login_user['user'] = $this->Dashboard->check($data);
		if(empty($data['email'] || $data['password']))
		{
			$error['errors'] = "You're user name or password cannot be empty!!!";	
			$this->load->view('register', $error);
		}
		elseif(empty($login_user['user']))
		{
			$error['errors'] = "You're user name and password do not match!!!";	
			$this->load->view('sign_in', $error);
		}	
		elseif($login_user['user']['email_address'] == $data['email'] && $login_user['user']['password'] == $data['password'])
		{	
			$user_id = $login_user['user']['id'];
			$user_level = $login_user['user']['user_level'];
			$this->session->set_userdata('level', $user_level);
			$this->session->set_userdata('id', $user_id);
			$this->load->view('message_board', $login_user);
		}
		
	}
	public function registration()
	{
		$data['first_name'] = $this->input->post('first_name');
		$data['last_name'] = $this->input->post('last_name');
		$data['email'] = $this->input->post('email');
		$data['password'] = $this->input->post('password');
		$data['confirm'] = $this->input->post('confirm');
		$this->form_validation->set_rules("first_name", "First Name", "trim|required");
		$this->form_validation->set_rules("last_name", "Last Name", "trim|required");
		$this->form_validation->set_rules("email", "Email", "trim|required|is_unique[users.email_address]|valid_email");
		$this->form_validation->set_rules("password", "Password", "trim|required|min_length[8]");
		$this->form_validation->set_rules("confirm", "Confirm Password", "trim|required|min_length[8]|matches[password]");
		
		if($this->form_validation->run())
		{
		    $new_user = $this->Dashboard->add($data);
		    $login_user['user'] = $this->Dashboard->check($data);
		    $this->load->view('message_board', $login_user);
		}
		else
		{

		    $view_data["errors"] = validation_errors();
		    $this->load->view('register', $view_data);
		}
	}
	function message()
	{
		$message['message'] = $this->input->post('message');
	}
	// function comment($post)
	// {
	// 	$comment = escape_this_string($_POST['draft_comment']);
	// 		$query2 =  "INSERT INTO comments(comment, created_at, updated_at, messages_id, users_id) VALUES ('$comment', NOW(), NOW(), {$_POST['message_id']}, {$_SESSION['user_id']})";
	// 			run_mysql_query($query2);
	// 			header('Location: wall.php');
	// 			die();
	// 			unset($_POST['message_id']);
	// }
	// function delete($post)
	// {
	// 	$query3= "DELETE FROM comments WHERE comments.messages_id= {$_POST['delete_id']}";
	// 	run_mysql_query($query3);
	// 	$query4= "DELETE FROM messages WHERE messages.id= {$_POST['delete_id']}";
	// 	run_mysql_query($query4);
	// 	header('Location: wall.php');
	// 	die();
	// }
}
//end of main controller