<?php
class Dashboard extends CI_Model {
	function add($user_data)
	{
		$query = "INSERT INTO users(first_name, last_name, email_address, password, user_level, created_at, updated_at) VALUES(?,?,?,?,?,?,?)";
		$values = array($user_data['first_name'], $user_data['last_name'], $user_data['email'], $user_data['password'], 2, date("Y-m-d, H:i:s"), date("Y-m-d, H:i:s"));
		return $this->db->query($query, $values);
	}
	function check($user_data)
	{
		$query = "SELECT * FROM users WHERE '{$user_data['email']}' = users.email_address AND '{$user_data['password']}' = users.password";
		return $this->db->query($query)->row_array();
	}
	function get_user_by_id($id)
	{
		$query = "SELECT * FROM users WHERE {$id} = users.id";
		return $this->db->query($query)->row_array();
	}
	function all()
	{
		$query = "SELECT * FROM users";
		return $this->db->query($query)->result_array();
	}
		function admin_update_user_info($user_info)
	{
		$query = "UPDATE users SET users.email_address ='{$user_info['email']}', users.first_name ='{$user_info['first_name']}', users.last_name ='{$user_info['last_name']}', users.user_level = {$user_info['level']}
		WHERE users.id = {$user_info['id']}";
		return $this->db->query($query);
	}
	function update_user_info($user_info)
	{
		$query = "UPDATE users SET users.email_address ='{$user_info['email']}', users.first_name ='{$user_info['first_name']}', users.last_name ='{$user_info['last_name']}'
		WHERE users.id = {$user_info['id']}";
		return $this->db->query($query);
	}
	function update_password($user_info)
	{
		$query = "UPDATE users SET users.password ='{$user_info['password']}', users.password ='{$user_info['password']}'
		WHERE users.id = {$user_info['id']}";
		return $this->db->query($query);
	}
	function update_description($user_info)
	{
		$query = "UPDATE users SET users.description ='{$user_info['description']}'
		WHERE users.id = {$user_info['id']}";
		return $this->db->query($query);
	}
	function delete_user_by_id($id)
	{
		$query = "DELETE FROM users WHERE {$id} = users.id";
		return $this->db->query($query);
	}
	// $message = escape_this_string($_POST['message']);
	// 		$query =  "INSERT INTO messages (message, created_at, updated_at, users_id) VALUES ('$message', NOW(), NOW(), {$_SESSION['user_id']})";
	// 		run_mysql_query($query);
	// 		header('Location: wall.php');
	// 		die();
// 	$query = "SELECT messages.message AS message, messages.users_id AS users_id, messages.id AS id, DATE_FORMAT(messages.updated_at, '%M %D %Y') AS time, DATE_ADD(messages.updated_at, interval 30 minute) AS time2, CONCAT(users.first_name ,' ', users.last_name) AS name FROM messages JOIN users ON users.id = messages.users_id ORDER BY messages.created_at";
// $messages = fetch_all($query);
// $query2 = "SELECT comments.comment AS comment, comments.messages_id AS id, DATE_FORMAT(comments.updated_at, '%M %D %Y') AS time, CONCAT(users.first_name ,' ', users.last_name) AS name FROM comments JOIN messages ON comments.messages_id = messages.id JOIN users ON users.id = comments.users_id ORDER BY comments.created_at";
// 	$comments = fetch_all($query2);
// $now= date("Y-m-d H:i:s");	

}

?>