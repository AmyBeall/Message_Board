
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign In</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  </head>
  <style>
	.message{
		width:750px;
		height:100px;
		padding:20px;
		font-size: 16px;
	}
	.comment{
		width:700px;
		height:80px;
		padding:20px;
		font-size: 16px;
	}
	.add_message{
	margin-left: 50px;
	}
	.add_message h4{
	font-size: 20px;
	}
	.add_comment{
		margin-left: 50px;
	}
	.display_message{
		margin-left: 50px;
		width:825px;
	}
	.display_comment{
		margin-left: 100px;
		width:725px;
	}
	.each_message{
		margin-left: 50px;
		font-size: 18px;
		width:750px;
	}
	.each_comment{
		margin-left: 50px;
		width:650px;
	}
	.button_m{
		border:solid black 2px;
		margin-left: 675px;
		background-color: blue;
		color:white;
	}
	.button_c{
		border:solid black 2px;
		margin-left: 625px;
		background-color: green;
		color:white;
	}
	.delete{
		border:solid black 2px;
		margin-left: 50px;
	}
   .navbar{
    padding-right: 65px;
    padding-left: 50px;
 	 }
  	.right{
      float:right;
    }
    .container h4{
      display:inline-block;
      margin-top: auto;
    }
    .container a{
      margin-top: auto;
    }
    .container h4, a{
      padding:10px;
    }
	body { 
      padding: 70px; 
    }
    .form input{
    	display:block;
    }
  </style>
  <body>
  

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <h4> Test App</h4>
       <a href="/dashboards/<?php if($this->session->userdata('level') == 9){echo "manage_users";}else{echo "display_users";}?>">Dashboard</a>
        <a href="/dashboards/profile">Profile</a>
        <a class="right" href="/dashboards/sign_in"> Log Off</a>
      </div>
    </nav>
    <div>
    	<h2><?=$user['first_name'];?> <?=$user['last_name'];?></h2>
    	<p>Registered at: <?=$user['created_at'];?></p>
    	<p>User Id: <?=$user['id'];?></p>
    	<p>Email Address: <?=$user['email_address'];?></p>
    	<p>Description: <?=$user['description'];?></p>
    </div>
	<div class='add_message'>
		<h4> Leave a message for <?=$user['first_name'];?></h4> 
		<form action='/dashboards/message/<?=$user['id']?>' method='post'>
			<textarea class = 'message' name = 'message'></textarea><br>
			<input type = 'hidden' name = 'comment' value = 'message'>
			<input  class = 'button_m' type = 'submit' value = 'Post a message!'>
		</form>
	</div>
	<div class = 'display_message'>
		
					<div class='add_comment'>
						<h4> Post a comment </h4> 
						<form action='process.php' method='post'>
							<textarea class = 'comment' name = 'draft_comment'></textarea><br>
							<input type='hidden' name = 'message_id' value='<?=$messages[$i]['id']?>'>
							<input type = 'hidden' name = 'comment' value = 'entered_comment'>
							<input class = 'button_c' type = 'submit' value = 'Post a comment!'>
						</form>
					</div>
			
	</div>	
</body>
</html>