<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit User</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  </head>
  <style>
  .navbar{
    padding-right: 65px;
    padding-left: 50px;
 	 }
  	.right{
      float:right;
    }
    .container h4{
      display:inline-block;
      margin-top: auto;
    }
    .container a{
      margin-top: auto;
    }
    .container h4, a{
      padding:10px;
    }
	body { 
      padding: 70px; 
    }
    .form input{
    	display:block;
    }
    tbody tr:nth-child(odd)
    {
   		background-color: #ccc;
	}
  </style>
  <body>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <h4> Test App</h4>
        <a href="/dashboards/<?php if($this->session->userdata('level') == 9){echo "manage_users";}else{echo "display_users";}?>">Dashboard</a>
        <a href="/dashboards/profile">Profile</a>
        <a class="right" href="/dashboards/sign_in"> Log Off</a>
      </div>
    </nav>
     <h4>Edit User <?=$user['id']?>:</h4>
    <form class="form" action="/dashboards/admin_update_user_info/<?=$user['id']?>" method='post'>
    	Email Address: <input type="text" name="email" placeholder="<?=$user['email_address']?>">
    	First Name: <input type="text" name="first_name" placeholder="<?=$user['first_name']?>">
    	Last Name: <input type="text" name="last_name" placeholder="<?=$user['last_name']?>">
    	User Level: <select name='level'><option name='admin'>Admin</option><option name='normal'>Normal</option></select>
    	<input type="submit" value="Save">
    </form>
    <h4>Change Password:</h4>
    <form class="form" action="/dashboards/admin_update_password/<?=$user['id']?>" method='post'>
    	Password: <input type="text" name="password">
    	Confirmation password: <input type="text" name="confirm">
    	<input type="submit" value="Update Password">
    </form>
</body>