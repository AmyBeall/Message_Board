<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 101 Template</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  </head>
  <style>
	.navbar{
	    padding-right: 65px;
	    padding-left: 50px;
	}
    .jumbotron{
      background-color: gray;
      border-radius: 10px;
    }
    .btn{
      background-color: blue;
      color:white;
      text-decoration: none;
      border: solid black 2px;
    }
    body { 
      padding: 70px; 
    }
    .right{
      float:right;
    }
    .container h4{
      display:inline-block;
      margin-top: auto;
    }
    .container a{
      margin-top: auto;
    }
    .container h4, a{
      padding:10px;
    }
  </style>
  <body>
  

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <h4> Test App</h4>
        <a href="/dashboards/index"> Home</a>
        <a class="right" href="/dashboards/sign_in"> Sign In</a>
      </div>
    </nav>
    <div class="jumbotron" span>
      <h1>Welcome to the Test</h1>
      <p> We're going to build a cool application using a MVC framework! This application was built with the Village88 folks!</p>
      <p><a class="btn btn-primary btn-lg" href="/dashboards/register" role="button">Start</a></p>
    </div>
    <div class="row">
      <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
          <div class="caption">
            <h3>Manage Users</h3>
            <p>Using this application, you'll learn how to add, remove, and edit users for the application.</p>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
          <div class="caption">
            <h3>Leave messages</h3>
            <p>Users will be able to leave a message to another user using this application.</p>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
          <div class="caption">
            <h3>Edit User Information</h3>
            <p>Admins will be able to edit another user's information (email address, first name, last name, etc).</p>
          </div>
        </div>
      </div>
   </div>
  </body>
</html>